export const VAULT_ADDRESS = "0xDDA9bF84d2bBb543B49Dd9dB4f32de3c7b19aCa2"; // Replace with yours
export const USDC_ADDRESS = "0x2d725a49175c77A44538EBcEFE09cB7AB82D6794"; // Sepolia USDC
